package SampleGame;

public class Castle {
	String duke_owner;
	int treasure;
	int level;
	Soldier reserves;
	Order target;
	int door;
}
