package SampleGame;

public class Kingdom {
	Castle[] origin_castles;
	Castle[] neutrals;
	/*Implémenter la campagne....*/
}
