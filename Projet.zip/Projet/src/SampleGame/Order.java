package SampleGame;

public class Order {
	Castle target;
	int troops;
}
