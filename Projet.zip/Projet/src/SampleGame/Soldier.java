package SampleGame;

public class Soldier {
	String name;
	int cost;
	int time_prod;
	int speed;
	int health;
	int damage;
	
	
}
